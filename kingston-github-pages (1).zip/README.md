# Kingston — GitHub Pages

## Files
- `index.html` — the Kingston website. GitHub Pages uses this as the site homepage.

## Publish it
1. Sign in to GitHub and create a **new public repository** named `kingston` (or another name you like).
2. Open the repository and choose **Add file → Upload files**.
3. Upload `index.html` from this folder and commit the change.
4. Open **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Choose the `main` branch and `/(root)`, then save.
7. Wait for GitHub Pages to publish the site; the Pages panel will show the website URL.

## Important limitations
- This is a static, single-file site, so it can be hosted on GitHub Pages without a build step.
- Music and movie buttons depend on the browser and the external services/content they link to. The movie section currently plays **trailers**, not full copyrighted movies.
- Live news and remote album artwork depend on third-party websites/APIs being reachable; they can fail if those services change or block requests.
- The current AI code calls **Google Gemini**, not the OpenAI API, and it starts with no API key configured.
- **Do not paste an OpenAI or Gemini secret API key into public HTML or commit it to GitHub.** Anyone can view a key embedded in a public website and use it. For secure AI chat, Kingston needs a small backend/serverless function that stores the key privately; GitHub Pages alone cannot keep a secret key safe.
- This package does not contain an API key.
